import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RiegoPage } from './riego';

@NgModule({
  declarations: [
    RiegoPage,
  ],
  imports: [
    IonicPageModule.forChild(RiegoPage),
  ],
})
export class RiegoPageModule {}
