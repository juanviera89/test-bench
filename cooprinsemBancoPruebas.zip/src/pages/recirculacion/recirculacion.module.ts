import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RecirculacionPage } from './recirculacion';

@NgModule({
  declarations: [
    RecirculacionPage,
  ],
  imports: [
    IonicPageModule.forChild(RecirculacionPage),
  ],
})
export class RecirculacionPageModule {}
